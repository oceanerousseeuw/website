/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include "jeu.h"
#include "laby.h"
#include "player.h"
#include "wish.h"
#include "monstre.h"
#include "combats.h"

bool caseDejaVisite(std::vector<int> vec, int value){
	for(unsigned i=0; i<vec.size(); i++){
		if(vec[i]==value)return true;
	}
	return false;
}

void auxPathFinding(const laby &L, int indice, std::vector<int> temp, std::vector<int> &path){
	
	temp.push_back(indice);
	
	if(indice != L.entreeX * L.dimY + L.entreeY){ //si on n'a pas trouvé l'entrée on continue la propagation des chemins
		int indiceCible; // prochaine case
		
		//cas Nord
		if(!(L.tab[indice]&(1 << Nord))){ //si il existe un Nord c'est à dire qu'il n'y a pas de mur
			indiceCible=indice-L.dimY; //on calcule l'indice de la case ciblée (le prochain indice)
			if(!caseDejaVisite(temp,indiceCible)){ //si la case n'a pas déjà été visité
				auxPathFinding(L,indiceCible,temp,path); //on relance la fonction avec le nouvel indice
			}
		}
		
		//cas Sud
		if(!(L.tab[indice]&(1 << Sud))){
			indiceCible=indice+L.dimY;
			if(!caseDejaVisite(temp,indiceCible)){
				auxPathFinding(L,indiceCible,temp,path);
			}
		}
		
		//cas Est
		if(!(L.tab[indice]&(1 << Est))){
			indiceCible=indice+1;
			if(!caseDejaVisite(temp,indiceCible)){
				auxPathFinding(L,indiceCible,temp,path);
			}
		}
		
		//cas Ouest
		if(!(L.tab[indice]&(1 << Ouest))){
			indiceCible=indice-1;
			if(!caseDejaVisite(temp,indiceCible)){
				auxPathFinding(L,indiceCible,temp,path);
			}
		}
		
	}else{ // fin de récursivité : entrée trouvée
		if(path.size() == 0 or temp.size()<path.size()){ // si c'est le 1er chemin trouvé ou si plus court
			path = temp;
		}
	}
	
	
}

int pathFinding(const laby &L, const player &p){
	int indiceJoueur = p.posX * L.dimY + p.posY;
	int indiceEntree = L.entreeX * L.dimY + L.entreeY;
		
	//on créer un vecteur qui servira a stocker le chemin des prédécesseurs définitif
	std::vector<int> path;
	//vecteur contenant les indices des cases formant le chemin qui sera utilisé uniquement dans la fonction récursive
	std::vector<int> temp; //vecteur temporaire
	
	auxPathFinding(L,indiceJoueur,temp,path);
	
	if(indiceJoueur==indiceEntree){ //si le joueur est déjà sur l'entrée et qu'il fuit, il reste à l'entrée
		
		return indiceEntree;
		
	}else{ //sinon on lui trouve un indice aléatoire que l'on retourne et qui deviendra son indice
		
		int alea = rand()%((path.size()-1)-(1) + 1) + 1;
		return path[alea];
		
	}
}

bool finPartie(const player &p, const std::vector<monstre> &m){
	if((m.size() == 0) or (p.party.size() == 0)){
		return true;
	}
	return false;
}

void regles(){
	std::cout << "\n  --- Bienvenue dans le jeu du Labyrinthe. ---  \n" << std::endl;
	std::cout << "Vous pouvez generer differentes tailles de labyrinthe mais preferez les tailles carrees." << std::endl;
	std::cout << "Vous devez battre les " << NB_MONSTRES << " monstres presents dans ce dedale!" << std::endl;
	std::cout << "Lorsqu'un monstre est rencontre vous pourrez voir ses caracteristiques affichees et choisir de combattre ou de vivre dans la honte...\n" << std::endl;
	std::cout << "La partie s'arrete lorsque tous les monstres ont etes vaincus ou que les membres de votre groupe ont fini demembres, desintegres ou encore fous errant dans leur tombeau..." << std::endl;
}

void jouer(const laby &L, const int &scale_factor, player &p, std::vector<monstre> &m){
	int sortieWish;
	int indiceJ = p.posX * L.dimY + p.posY;
	bool caseMonstre;
	
	regles();
	
	draw2D(L,scale_factor);
	infosJoueurs(p);
	
	while(!finPartie(p,m)){
		
		refreshLaby(L,scale_factor,p,m);//on nettoie l'affichage
		
		caseMonstre = presenceMonstre(p,m,caseMonstre);
		
		fscanf(fp_from_wish, " %d", &sortieWish);//on récupère la sortie de wish (les boutons)
		
		switch(sortieWish){
			case 2://je regarde à gauche
				if(!caseMonstre){
					switch(p.view){
						case Nord:
							p.view = Ouest;
							break;
						case Est:
							p.view = Nord;
							break;
						case Sud:
							p.view = Est;
							break;
						case Ouest:
							p.view = Sud;
							break;
					}
				}
				break;
			
			case 8://je regarde à droite
				if(!caseMonstre){
					switch(p.view){
						case Nord:
							p.view = Est;
							break;
						case Est:
							p.view = Sud;
							break;
						case Sud:
							p.view = Ouest;
							break;
						case Ouest:
							p.view = Nord;
							break;
					}
				}
				break;
				
			case 4://j'avance
				if(!caseMonstre){
					switch(p.view){
						case Nord:
							if(!(L.tab[indiceJ]&(1<<Nord))){
								p.posX--;
							}
							break;
						case Est:
							if(!(L.tab[indiceJ]&(1<<Est))){
								p.posY++;
							}
							break;
						case Sud:
							if(!(L.tab[indiceJ]&(1<<Sud))){
								p.posX++;
							}
							break;
						case Ouest:
							if(!(L.tab[indiceJ]&(1<<Ouest))){
								p.posY--;
							}
							break;
					}
				}
				break;
				
			case 10:
				if(caseMonstre){
					indiceJ = pathFinding(L,p);
					p.posX = indiceJ/L.dimY;
					p.posY = indiceJ%L.dimY;
					fprintf(fp_to_wish,".a.t delete 0.0 end\n");
					std::cout << "Pendant votre fuite vous entendez le monstre rire aux eclats..." << std::endl;
				}else{
					std::cout << "De quoi voulez vous fuir? Reprennez vous!" << std::endl;
				}
				break;
				
			case 12:
				if(caseMonstre){
					combat(m,p,L);
					fprintf(fp_to_wish,".a.t delete 0.0 end\n");
					infosJoueurs(p);
				}else{
					std::cout << "Vous combattez un malheureux asticot, felicitations vous gagnez 0 pieces." << std::endl;
				}
				break;
				
			case 0:
				std::cout << "Alors comme ca on ne se sent pas de taille?" << std::endl;
				fprintf(fp_to_wish,"exit\n");
				exit(0);
				break;
					
		}
		
		indiceJ = p.posX * L.dimY + p.posY;
		
	}
	
	if(m.size()==0){
		std::cout << "\n --- FELICITATIONS --- \n" << "Score : " << p.sac << " pieces.\n" << std::endl;
	}
	
	fprintf(fp_to_wish,"exit\n");
}
