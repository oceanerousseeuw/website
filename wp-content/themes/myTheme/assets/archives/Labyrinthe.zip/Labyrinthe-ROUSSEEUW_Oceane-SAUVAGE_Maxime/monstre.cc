/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>

#include "monstre.h"
#include "laby.h"
#include "player.h"
#include "wish.h"

void initMonstres(std::vector<monstre> &m, const laby &L){ //sans le typedef l'équivalent serait monstre *m
	
	std::vector<std::string> nomsMonstres={"Scar","Bowser","Cortex","Diablo","MisterT","Archimonde","ShaunT","Alien","Joker","Mandarin","Ajax","Tony"};
	int alea;
	
	bool indiceValide; //booléen qui permet de savoir si l'indice prit par le monstre est valide ou non
	
	monstre temp;
	
	//on va créer autant de monstres qu'on veut selon la variable NB_MONSTRES (cf. player.h)
	int cpt=0;
	do{
		alea=alea=rand()%nomsMonstres.size();
		temp.name=nomsMonstres[alea];
		//un nom unique est utilisé par monstre
		nomsMonstres.erase(nomsMonstres.begin() + alea);
		
		temp.initiative=2*(rand()%(4-1)+1);
		temp.attaque=2*(rand()%(4-1)+1);
		temp.defense=2*(rand()%(4-1)+1);
		temp.pv=8+ 3*(rand()%(6-1)+1);
		temp.tresor=5+3*(rand()%(6-1)+1);
		
		
		do{
			indiceValide=true;
			
			//on assigne les positions des monstres
			temp.posX = rand()%L.dimX;
			temp.posY = rand()%L.dimY;
			
			//si l'indice est celui de l'entrée alors l'indice n'est pas valide et on relancera la boucle
			if(temp.posX == L.entreeX and temp.posY == L.entreeY){
				indiceValide=false;
			}
			
			//de même si l'indice à déjà été prit par un monstre précédent
			for(unsigned i=0; i<m.size(); i++){
				if((temp.posX == m[i].posX) and (temp.posY == m[i].posY)){
					indiceValide=false;
				}
			}
			
		}while(indiceValide==false);
		
		m.push_back(temp);
		cpt++;
		
	}while(cpt<NB_MONSTRES);
}

bool presenceMonstre(const player &p, std::vector<monstre> &m, bool dejaAfficher){
	for(unsigned i=0; i<m.size(); i++){
		if((m[i].posX == p.posX) and (m[i].posY == p.posY)){
			if(!dejaAfficher){
				fprintf(fp_to_wish,".a.t insert 0.3 \"PV : %d\n\"\n",m[i].pv);
				fprintf(fp_to_wish,".a.t insert 0.2 \"défense : %d\n\"\n",m[i].defense);
				fprintf(fp_to_wish,".a.t insert 0.1 \"attaque : %d\n\"\n",m[i].attaque);
				fprintf(fp_to_wish,".a.t insert 0.0 \"%s\n\"\n",m[i].name.c_str());
			}
			return true;
		}
	}
	return false;
}
