/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include "laby.h"

void laby::initLaby(unsigned x, unsigned y){
	//X = lignes, Y = colonnes       tab[X][Y]
	dimX = x;
	dimY = y;
	tab = (unsigned*)malloc(dimX*dimY*sizeof(unsigned));
	
	for(unsigned i=0;i<(dimX*dimY);i++){
		tab[i]=15; // toutes les cellules sont fermées
	}
	
	int a;
	a=rand()%4; //On choisit un côté aléatoire de début et de fin
	
	switch (a){
		case 0: //haut gauche
			entreeX = 0;
			entreeY = 0;
			break;
		case 1: //haut droite
			entreeX = 0;
			entreeY = dimY-1;
			break;
		case 2: //bas droite
			entreeX = dimX-1;
			entreeY = dimY-1;
			break;
		case 3: //bas gauche
			entreeX = dimX-1;
			entreeY = 0;
			break;
	}
	
}

void afficherLaby(laby &L){
	unsigned chariot = L.dimY-1; //Le tableau est initialisé en 1D mais on veut un tableau 2D donc on fait un retour chariot selon les dimensions choisies
	for(unsigned i=0; i < L.dimX*L.dimY; i++){
		if(L.tab[i] == 15){
			printf("\x1B[34m %3d \x1B[0m", L.tab[i]);
		}else{
			printf("%3d", L.tab[i]);
		}
		if(i == chariot){
			printf("\n");
			chariot += L.dimY;
		}
	}
	printf("L.entreeX : %d\nL.entreeY : %d\n\n",L.entreeX,L.entreeY);
}

bool nonVisite(unsigned coord, std::vector<unsigned> arbre){
	//on retourne vrai si la case n'a pas encore été visitée (=stockée dans le vecteur)
	for(unsigned j=0; j<arbre.size(); j++){
		if(coord == arbre[j]){
			return false;
		}
	}
	return true;
}

void initArbre(laby &L, std::vector<unsigned> arbre){
	// creer tab aleatoire auxilliaire représentant le coût des arcs
	unsigned *arcs = (unsigned *) malloc (sizeof(unsigned)*L.dimX*L.dimY);

	for (unsigned i = 0; i < L.dimX*L.dimY; i++){
		arcs[i] = rand()%99; // la valeur des arcs va de 0 à 99
	}
	
	// on utilise un vecteur pour représenter l'arbre pour Prim
	arbre.push_back(L.entreeX*L.dimY + L. entreeY); //On entre les coordonnes de l'entree
	
	//declaration de variables, explication lors de leur utilisation plus bas
	unsigned cout_min, coord_ajout, coord_actu, coord_murRelie;
	dir dir_murRelie, dir_ajout;
	char symb = '%';
	
	while(arbre.size()<L.dimX*L.dimY){ //tant qu'on n'a pas fait toutes les cases
		cout_min = 1000; 
		/*les arcs vont de 0 à 99, 1000 est donc une valeur impossible
		 * on trouvera forcément une valeur plus petite*/

		/*on parcourt l'arbre (vector) et on cherche parmis les voisins 
		 * non visités le coût minimum puis on l'intégre dans l'arbre*/
		for(unsigned i=0; i<arbre.size();i++){
			coord_actu = arbre[i];
			//on regarde,l'elem précédent la case à "GAUCHE" (tableau 2D)
			if((coord_actu % L.dimY != 0) && nonVisite(coord_actu-1,arbre)){ //si on ne sort pas des dimensions
				if(cout_min > arcs[coord_actu-1] + arcs[coord_actu]){
					/*si l'arc est le plus petit coût on actualise cout_min
					 * et on retient les coordonnées de la case*/
					cout_min = arcs[coord_actu-1] + arcs[coord_actu];
					coord_ajout = coord_actu-1;
					/*si l'elem est prit on casse le mur pour celui-ci est l'elem actuel*/
					coord_murRelie = coord_actu;
					dir_murRelie = Ouest;
					dir_ajout = Est;
				}
			}
			
			//idem DROITE
			if((coord_actu % L.dimY != L.dimY - 1) && nonVisite(coord_actu+1,arbre)){
				if(cout_min > arcs[coord_actu+1] + arcs[coord_actu]){
					cout_min = arcs[coord_actu+1] + arcs[coord_actu];
					coord_ajout = coord_actu+1;
					coord_murRelie = coord_actu;
					dir_murRelie = Est;
					dir_ajout = Ouest;
				}
			}
			
			//idem HAUT
			if((coord_actu >= L.dimY) && nonVisite(coord_actu-L.dimY,arbre)){
				// exemple avec T[7][7] : dimY = 7 et le 7e elem est sur la 2e ligne car on commence à 0
				if(cout_min > arcs[coord_actu-L.dimY] + arcs[coord_actu]){
					cout_min = arcs[coord_actu-L.dimY] + arcs[coord_actu];
					coord_ajout = coord_actu-L.dimY;
					coord_murRelie = coord_actu;
					dir_murRelie = Nord;
					dir_ajout = Sud;
				}
			}
			
			//idem BAS
			if((coord_actu < L.dimX*(L.dimY-1)) && nonVisite(coord_actu+L.dimY,arbre)){
				if(cout_min > arcs[coord_actu+L.dimY] + arcs[coord_actu]){
					cout_min = arcs[coord_actu+L.dimY] + arcs[coord_actu];
					coord_ajout = coord_actu+L.dimY;
					coord_murRelie = coord_actu;
					dir_murRelie = Sud;
					dir_ajout = Nord;
				}
			}
			
		}//fin for, on ressort avec la position (coord_ajout) de l'arc le moins couteux
		
		//pour vérifier l'arbre décommenter :
		//printf("elem num %d = %d\n",coord_ajout,arcs[coord_ajout]);
		
		arbre.push_back(coord_ajout);
		
		//on casse les murs
		L.tab[coord_murRelie] = L.tab[coord_murRelie]^(1 << dir_murRelie);
		L.tab[coord_ajout] = L.tab[coord_ajout]^(1 << dir_ajout);
		
		int percent = (arbre.size() * 100) / (L.dimX*L.dimY);
		system("clear");
		printf("Generating labyrinth . . . %d%c\n",percent,symb);
		
	}//fin while
}
