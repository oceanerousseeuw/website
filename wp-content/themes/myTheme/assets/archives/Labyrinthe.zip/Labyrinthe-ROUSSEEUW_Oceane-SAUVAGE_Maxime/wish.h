/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef WISH_H
#define WISH_H

#include "laby.h"
#include "player.h"
#include "monstre.h"

//taille canvas vue 3D
#define TX 400
#define TY 200

#define PROFONDEUR_CHAMP 3 //pour la vue 3D

// descripteurs de tubes (variables globales)
extern FILE *fp_to_wish;
extern FILE *fp_from_wish;

int findScale(const laby &L);

void initWish();

void initCanvas(const laby &L, const int &scale_factor);

void draw2D(const laby &L, const int &scale_factor);

void drawPlayer(const int &scale_factor, const player &p);

unsigned cible(const player &p, int prof, int ecart, const laby &L);

void drawCell(int cell, int prof, int ecart, const laby &L, const player &p);

void draw3D(const laby &L, const player &p);

void drawMonstre(const laby &L, const int &scale_factor, const monstre &m, const std::string &nomMonstre);

void monstresAPortee(const laby &L, const int &scale_factor, const player &p, const std::vector<monstre> &m);

void refreshLaby(const laby &L, const int &scale_factor, const player &p, const std::vector<monstre> &m);

#endif
