/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef LABY_H
#define LABY_H

class laby{
	public:
		unsigned dimX, dimY;
		unsigned entreeX, entreeY;
		unsigned *tab;
		void initLaby(unsigned x, unsigned y);
};

enum dir{Nord,Est,Sud,Ouest};
	//Nord vaut 0, Est vaut 1 etc...

void afficherLaby(laby &L);

bool nonVisite(unsigned coord, std::vector<unsigned> arbre);

void initArbre(laby &L, std::vector<unsigned> arbre);

#endif
