/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef MONSTRE_H
#define MONSTRE_H

#include "laby.h"
#include "player.h"

#define NB_MONSTRES 8

struct monstre{
		std::string name;
		unsigned posX, posY;
		int initiative, attaque, defense;
		int pv;
		unsigned tresor;
};

void initMonstres(std::vector<monstre> &m, const laby &L);

bool presenceMonstre(const player &p, std::vector<monstre> &m, bool dejaAfficher);

#endif
