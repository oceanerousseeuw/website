/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>

#include "player.h"
#include "laby.h"
#include "wish.h"

std::vector<aventurier> initAventuriers(){
	std::vector<std::string> nomsAventuriers{"Bryan","Eddy","Batman","Rambo","Chuck","Indiana","Borris","Catwoman","Minion"};
	std::vector<aventurier> party;
	aventurier a;
	
	int alea;
	int i=0;
	while(i<PARTY_SIZE){
		alea=rand()%nomsAventuriers.size();
		a.name=nomsAventuriers[alea];
		//un nom unique est utilisé par aventurier
		nomsAventuriers.erase(nomsAventuriers.begin() + alea);
		
		a.initiative=1+(rand()%(6-1)+1);
		a.attaque=1+(rand()%(6-1)+1);
		a.defense=1+(rand()%(6-1)+1);
		a.pv=10+ 2*(rand()%(6-1)+1);
		
		party.push_back(a);
		
		i++;
	}
	return party;
}

void initJoueur(player &p, laby &L){
	p.posX = L.entreeX;
	p.posY = L.entreeY;
	
	if(p.posX == 0){
		p.view = Sud;
	}else{
		p.view = Nord;
	}
	
	p.party = initAventuriers();
	
	p.sac = 0;
}

void infosJoueurs(const player &p){
	fprintf(fp_to_wish,".a.u delete 0.0 end\n");
	int PVtotaux=0, ATTtotale=0, DEFtotale=0;
	for(unsigned i=0; i<p.party.size(); i++){
		if(p.party[i].pv > 0){
			PVtotaux += p.party[i].pv;
			DEFtotale += p.party[i].defense;
			ATTtotale += p.party[i].attaque;
		}
	}
	fprintf(fp_to_wish,".a.u insert 0.4 \"argent : %d\n\"\n",p.sac);
	fprintf(fp_to_wish,".a.u insert 0.3 \"défense : %d\n\"\n",DEFtotale);
	fprintf(fp_to_wish,".a.u insert 0.2 \"attaque : %d\n\"\n",ATTtotale);
	fprintf(fp_to_wish,".a.u insert 0.1 \"PV : %d\n\"\n",PVtotaux);
	fprintf(fp_to_wish,".a.u insert 0.0 \"Infos Joueur\n\"\n");
	
}
