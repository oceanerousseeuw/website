/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <time.h>

#include "combats.h"
#include "monstre.h"
#include "player.h"
#include "wish.h"
#include "jeu.h"

bool aventuriersDejaAttaquer(std::vector<bool> &dejaAttaquer){
	int compteur=0;
	for(unsigned i=0; i<dejaAttaquer.size(); i++){
		if(dejaAttaquer[i]){
			compteur++;
		}
	}
	if(compteur == dejaAttaquer.size()){
		return true;
	}
	return false;
}

void resetBool(std::vector<bool> &dejaAttaquer, bool &monstreAattaquer){
	int compteur=0;
	for(unsigned i=0; i<dejaAttaquer.size(); i++){
		if(dejaAttaquer[i]){
			compteur++;
		}
	}
	if(monstreAattaquer){
		compteur++;
	}
	
	if(compteur == (dejaAttaquer.size()+1)){
		for(unsigned j=0; j<dejaAttaquer.size(); j++){
			dejaAttaquer[j] = false;
		}
		monstreAattaquer = false;
	}
}

void aventurierFrappe(aventurier &a, monstre &m){
	int forceAttaque = (rand()%(6-1)+1) + a.attaque - m.defense;
	if(forceAttaque > 0){
		std::cout << a.name << " attaque le monstre pour " << forceAttaque << " degats." << std::endl;
		m.pv -= forceAttaque;
	}else{
		std::cout << a.name << " attaque mais ne parvient pas a blesser le monstre." << std::endl;
	}
}

void monstreFrappe(monstre &m, player &p, std::vector<bool> &dejaAttaquer){
	int forceAttaque = (rand()%(6-1)+1) + m.attaque;
	if(forceAttaque > 0){
		int cible = rand()%p.party.size();
		p.party[cible].pv -= (forceAttaque - p.party[cible].defense);
		std::cout << "\nLe monstre frappe pour " << forceAttaque << " degats." << std::endl;
		std::cout << p.party[cible].name << " bloque " << p.party[cible].defense << " degats.\n"<< std::endl;
		if(p.party[cible].pv <= 0){
			std::cout << "Cependant l'attaque de son adversaire aura eu raison de " << p.party[cible].name << " qui s'effondre dans une marre de sang.\n" << std::endl;
			p.party.erase(p.party.begin() + cible);
			dejaAttaquer.erase(dejaAttaquer.begin() + cible);
		}
	}
}

void combat(std::vector<monstre> &m, player &p, const laby &L){
	int numeroMonstre;
	//on cherche le bon indice de monstre, soit le monstre rencontré
	for(unsigned i=0; i<m.size(); i++){
		if((m[i].posX == p.posX) and (m[i].posY == p.posY)){
			numeroMonstre=i;
		}
	}
	
	//on créer un nouveau joueur avec les nouvelles iniatives (pour ne pas modifier celles de bases)
	player tempPlayer = p;
	for(unsigned j=0; j<tempPlayer.party.size(); j++){
		tempPlayer.party[j].initiative += (rand()%(6-1)+1);
	}
			
	//idem avec le monstre
	monstre tempMonstre = m[numeroMonstre];
	tempMonstre.initiative += (rand()%(6-1)+1);
								
	//on créer un vecteur de booléens pour savoir si les protagonistes ont attaqués ou non, pour savoir qui doit attaqué
	std::vector<bool> dejaAttaquer (p.party.size(), false);
	int attaquantAventurier=0;
	bool monstreAattaquer = false;
								
	//tq que les adversaires ont des points de vie
	while((tempPlayer.party.size() > 0) and (tempMonstre.pv > 0)){
		
		attaquantAventurier = 0;
				
		//on assigne un attaquant côté aventurier qui n'a pas encore attaqué et qui est en vie puis on comparera les initiatives
		while((attaquantAventurier < p.party.size())  and (dejaAttaquer[attaquantAventurier])){
			attaquantAventurier++;
		}
					
		//on cherche selon l'iniative quel aventurier attaquera en premier
		for(unsigned k=0; k<tempPlayer.party.size(); k++){
			if((tempPlayer.party[k].initiative >= tempPlayer.party[attaquantAventurier].initiative) and (!dejaAttaquer[k])){
				attaquantAventurier=k;
			}
		}
					
		//on a l'aventurier avec la plus grande iniative que l'on compare a celle du monstre si celui ci n'a pas encore attaqué
		if((tempPlayer.party[attaquantAventurier].initiative > tempMonstre.initiative) or (monstreAattaquer)){
			//l'aventurier attaque
			aventurierFrappe(tempPlayer.party[attaquantAventurier], tempMonstre);
			dejaAttaquer[attaquantAventurier] = true;
		}
		
		if((tempPlayer.party[attaquantAventurier].initiative <= tempMonstre.initiative) and (!monstreAattaquer)){
			//le monstre attaque
			monstreFrappe(tempMonstre, tempPlayer, dejaAttaquer);
			monstreAattaquer = true;
		}
		
		//si les aventuriers ont déjà tous attaquer mais que leur initiative est toujours plus élevée que celle du monstre alors il attaque
		if((aventuriersDejaAttaquer(dejaAttaquer)) and (!monstreAattaquer)){
			//le monstre attaque
			monstreFrappe(tempMonstre, tempPlayer, dejaAttaquer);
			monstreAattaquer = true;
		}
		
		/*si tout le monde a attaquer sans vainqueur on remet les bool a false*/
		resetBool(dejaAttaquer,monstreAattaquer);
					
	}//fin while (un des adversaires est mort)
	
	if(tempPlayer.party.size() == 0){
		std::cout << "\n --- GAME OVER --- \n" << "Score : " << tempPlayer.sac << " pieces.\n" << std::endl;
		fprintf(fp_to_wish,"exit\n");
		exit(0);
	}
				
	if(tempMonstre.pv <= 0){
		std::cout << "\nLe monstre meurt dans d'horribles souffrances.\n" << "Les aventuriers gagnent " << tempMonstre.tresor << " pieces.\n" << std::endl;
		//le joueur gagne le trésor
		p.sac += tempMonstre.tresor;
				
		//on remet le bon nombre de points de vies dans le tableau d'aventuriers originel (seule chose à remettre)
		for(unsigned i=0; i<p.party.size(); i++){
			for(unsigned j=0; j<tempPlayer.party.size(); j++){
				if(p.party[i].name == tempPlayer.party[j].name){
					tempPlayer.party[j].initiative = p.party[i].initiative;
				}
			}
		}
		p.party = tempPlayer.party;
		
		//on supprime le monstre de l'affichage
		fprintf(fp_to_wish,".a.c delete \"%s\"\n",tempMonstre.name.c_str());
				
		//on supprime le monstre du vecteur
		m.erase(m.begin() + numeroMonstre);
	}
}
