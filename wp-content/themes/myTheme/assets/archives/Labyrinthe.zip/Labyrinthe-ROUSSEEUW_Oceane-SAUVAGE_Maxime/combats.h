/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef COMBATS_H
#define COMBATS_H

#include "monstre.h"
#include "player.h"

void resetBool(std::vector<bool> &dejaAttaquer, bool &monstreAattaquer);

void aventurierFrappe(aventurier &a, monstre &m);

void monstreFrappe(monstre &m, player &a);

void combat(std::vector<monstre> &m, player &p, const laby &L);


#endif
