/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <sys/types.h>
#include <unistd.h>

#include "wish.h"
#include "laby.h"
#include "player.h"
#include "monstre.h"

FILE *fp_to_wish;
FILE *fp_from_wish;

int findScale(const laby &L){
	//on cherche le bon facteur en fonction de la taille du labyrinthe
	int scale_factor;
	if(L.dimX*L.dimY <= 800){
		scale_factor = 15;
	}else{
		if(L.dimX*L.dimY <= 1200){
			scale_factor = 13;
		}else{
			if(L.dimX*L.dimY <= 1500){
				scale_factor = 10;
			}else{
				scale_factor = 8;
			}
		}
	}
	
	return scale_factor;
}

void initWish(){
  int   pid;
  int to_wish[2];  // pipe descriptors from parent->child
  int from_wish[2]; // pipe descriptors from child->parent

  pipe(to_wish);
  pipe(from_wish); 

  if (pid=fork(), pid==0) { // in child
    close(0); // redirect stdin
    dup(to_wish[0]);
    close(1); // redirect stdout
    dup(from_wish[1]);

    close(to_wish[0]); // close pipes
    close(to_wish[1]);
    close(from_wish[0]);
    close(from_wish[1]);
    execlp("wish", "wish", "-name", "Labyrinthe", NULL); // exec cmd

  } else if ( pid > 0 ) { // in parent
    fp_from_wish = fdopen(from_wish[0], "r");
    fp_to_wish = fdopen(to_wish[1], "w");
    setbuf(fp_to_wish, NULL); // no buffered output

    setbuf(stdout, NULL); // no buffered output for stdout
    
    close(to_wish[0]); // close unused pipes
    close(from_wish[1]);
  } else { // pb !
    throw;
  }
}

void initCanvas(const laby &L, const int &scale_factor){
	fprintf(fp_to_wish,"canvas .a -width %d -height %d\n",L.dimY*scale_factor+1+scale_factor, L.dimX*scale_factor+1);
	fprintf(fp_to_wish,"pack .a\n");
	
	fprintf(fp_to_wish,"canvas .a.c -width %d -height %d -background gray\n", L.dimY*scale_factor+1, L.dimX*scale_factor+1);
	fprintf(fp_to_wish,"pack .a.c -ipadx 0 -ipady 0 -pady 10\n");
	
	fprintf(fp_to_wish,"canvas .b -width 20 -height 5\n");
	fprintf(fp_to_wish,"pack .b\n");
	
	fprintf(fp_to_wish,"frame .f -width %d -relief ridge -bd 3 -padx 10 -pady 10\n", 40);
	fprintf(fp_to_wish,"pack .f\n");
	
	//fprintf(fp_to_wish,"button .f.b -text quit -command exit -background red\n");
	fprintf(fp_to_wish,"button .f.b -text quit -command \"puts 0\nflush stdout\" -background red\n");
	fprintf(fp_to_wish,"pack .f.b -side left\n");
	
	fprintf(fp_to_wish,"canvas .f.c2 -width %d -height %d -background gray -relief groove -bd 3\n", TX, TY);
	fprintf(fp_to_wish,"pack .f.c2 -side left\n");
	
	fprintf(fp_to_wish,"frame .f.f2 -width %d -relief raised -bd 3 -padx 10 -pady 10\n", 40);
	fprintf(fp_to_wish,"pack .f.f2 -side right\n");
	
	//on crée un nouveau frame pour les flèches gauche et droite...
	fprintf(fp_to_wish,"frame .f.f2.f3 -width %d\n", 35);
	
	
	fprintf(fp_to_wish,"button .f.f2.f3.g -text \"<\" -command \"puts 2\nflush stdout\"\n");
	fprintf(fp_to_wish,"button .f.f2.f -text \"^\" -command \"puts 4\nflush stdout\"\n");
	fprintf(fp_to_wish,"button .f.f2.f3.d -text \">\" -command \"puts 8\nflush stdout\"\n");
	fprintf(fp_to_wish,"pack .f.f2.f\n");
	fprintf(fp_to_wish,"pack .f.f2.f3\n"); //...il est packé dans .f.f2
	fprintf(fp_to_wish,"pack .f.f2.f3.g -side left\n");
	fprintf(fp_to_wish,"pack .f.f2.f3.d -side right\n");
	
	//on créer une fenêtre d'informations du monstre
	fprintf(fp_to_wish,"text .a.t -background black -foreground white -relief ridge -borderwidth 5 -font {Helvetica -15} -width 15 -height 5\n");
	fprintf(fp_to_wish,"pack .a.t -side left\n");
	
	//et une pour le joueur
	fprintf(fp_to_wish,"text .a.u -background black -foreground white -relief ridge -borderwidth 5 -font {Helvetica -15} -width 15 -height 5\n");
	fprintf(fp_to_wish,"pack .a.u -side right\n");
	
	//on créer un bouton de fuite
	fprintf(fp_to_wish,"button .b.e -text Escape -background red -command \"puts 10\nflush stdout\"\n");
	fprintf(fp_to_wish,"pack .b.e -side right\n");
	
	//on créer un bouton pour combattre
	fprintf(fp_to_wish,"button .b.f -text Fight -background yellow -command \"puts 12\nflush stdout\"\n");
	fprintf(fp_to_wish,"pack .b.f -side left\n");
	
}

void draw2D(const laby &L, const int &scale_factor){
	int posX, posY;
	
	for(unsigned i=0; i<L.dimX*L.dimY; i++){ //on parcourt les cases du labyrinthe
		if(L.tab[i] != 0){ //si on a des murs a placer
			//si jamais je sors des dimensions
			/* SOUS WISH LES X ET Y SONT DIFFERENTS ! */
			posY = i/L.dimY;
			posX = i%L.dimY;
			
			//Pour vérifier décommenter :
			//printf("%d, posX:%d, posY:%d\n",L.tab[i],posX,posY);
			
			if(L.tab[i]&(1 << Nord)){ //Mur Nord
				fprintf(fp_to_wish,".a.c create line %d %d %d %d\n", 
				(posX*scale_factor+1), 
				(posY*scale_factor+1), 
				(posX*scale_factor+1)+scale_factor, 
				(posY*scale_factor+1));
			}
			if(L.tab[i]&(1 << Ouest)){ //Mur Ouest
				fprintf(fp_to_wish,".a.c create line %d %d %d %d\n", 
				(posX*scale_factor+1), 
				(posY*scale_factor+1), 
				(posX*scale_factor+1), 
				(posY*scale_factor+1)+scale_factor);
			}
			if(L.tab[i]&(1 << Est)){ //Mur Est
				fprintf(fp_to_wish,".a.c create line %d %d %d %d\n", 
				(posX*scale_factor+1)+scale_factor, 
				(posY*scale_factor+1)+scale_factor, 
				(posX*scale_factor+1)+scale_factor, 
				(posY*scale_factor+1));
			}
			if(L.tab[i]&(1 << Sud)){ //Mur Sud
				fprintf(fp_to_wish,".a.c create line %d %d %d %d\n", 
				(posX*scale_factor+1)+scale_factor, 
				(posY*scale_factor+1)+scale_factor, 
				(posX*scale_factor+1), 
				(posY*scale_factor+1)+scale_factor);
			}			
		}
	}
}

void drawPlayer(const int &scale_factor, const player &p){
	//on positionne l'avatar du joueur
	switch (p.view){
		case Nord:
			fprintf(fp_to_wish,".a.c create line %d %d %d %d -arrow last -tag pos\n",
			(p.posY*scale_factor+scale_factor/2), 
			(p.posX*scale_factor+scale_factor), 
			(p.posY*scale_factor+scale_factor/2), 
			(p.posX*scale_factor)+1
			);
			break;
		case Sud:
			fprintf(fp_to_wish,".a.c create line %d %d %d %d -arrow last -tag pos\n", 
			(p.posY*scale_factor+scale_factor/2), 
			(p.posX*scale_factor)+1,
			(p.posY*scale_factor+scale_factor/2), 
			(p.posX*scale_factor+scale_factor)
			);
			break;
		case Est:
			fprintf(fp_to_wish,".a.c create line %d %d %d %d -arrow last -tag pos\n", 
			(p.posY*scale_factor)+1, 
			(p.posX*scale_factor+scale_factor/2), 
			(p.posY*scale_factor+scale_factor), 
			(p.posX*scale_factor+scale_factor/2)
			);
			break;
		case Ouest:
			fprintf(fp_to_wish,".a.c create line %d %d %d %d -arrow last -tag pos\n",
			(p.posY*scale_factor+scale_factor), 
			(p.posX*scale_factor+scale_factor/2),
			(p.posY*scale_factor)+1, 
			(p.posX*scale_factor+scale_factor/2)
			);
			break;
	}
}


unsigned cible(const player &p, int prof, int ecart, const laby &L){
	//printf("mon ecart : %d\n",ecart);
	
	int indice;
	
	dir d = p.view;
	switch(d){
		case Nord:
			//si je change de ligne ou je sors des dimensions alors indice prend -1 et ne sera pas déssiné par la suite
			indice = (p.posX-prof) * L.dimY + (p.posY+ecart);
			if(indice < 0 || indice/L.dimY != p.posX - prof){
				indice = -1;
			}
			break;
		case Sud:
			indice = (p.posX+prof) * L.dimY + (p.posY+ecart);
			if(indice > (L.dimX*L.dimY-1) || indice/L.dimY != p.posX + prof){
				indice = -1;
			}
			break;
		case Est:
			//si je change de colonne ou je sors des dimensions alors indice prend -1 et ne sera pas déssiné par la suite
			indice = (p.posX+ecart) * L.dimY + (p.posY+prof);
			if(indice > (L.dimX*L.dimY-1) || indice < 0 || indice%L.dimY != p.posY + prof){
				indice = -1;
			}
			break;
		case Ouest:
			indice = (p.posX+ecart) * L.dimY + (p.posY-prof);
			if(indice > (L.dimX*L.dimY-1) || indice < 0 || indice%L.dimX != p.posY - prof){
				indice = -1;
			}
			break;
	}
	return indice;
}

void drawCell(int cell, int prof, int ecart, const laby &L, const player &p){
	int scale=200, cpt=0;
	int milX=TX/2, milY=TY/2; //milieu du canvas
	
	//printf("Indice de la case : %d\n",cell);
	
	while(cpt < prof){//je cherche la bonne échelle en fonction de la profondeur
		scale=scale/2;
		cpt++;
	}
	
	switch(p.view){
		case Nord:
		
			if(L.tab[cell]&(1 << Nord)){//mur de face
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill blue\n",
				milX-scale/2+ecart*scale, milY-scale/2,
				milX+scale/2+ecart*scale, milY-scale/2,
				milX+scale/2+ecart*scale, milY+scale/2,
				milX-scale/2+ecart*scale, milY+scale/2);
			}
			
			if(L.tab[cell]&(1 << Ouest)){//mur à gauche
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX-scale+ecart*scale*2, milY-scale,
				milX-scale/2+ecart*scale, milY-scale/2,
				milX-scale/2+ecart*scale, milY+scale/2,
				milX-scale+ecart*scale*2, milY+scale);
			}
			
			if(L.tab[cell]&(1 << Est)){//mur à droite
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX+scale/2+ecart*scale, milY-scale/2,
				milX+scale+ecart*scale*2, milY-scale,
				milX+scale+ecart*scale*2, milY+scale,
				milX+scale/2+ecart*scale, milY+scale/2);
			}
			
		break;
		
		case Est:
		
			if(L.tab[cell]&(1 << Est)){//mur de face
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill blue\n",
				milX-scale/2+ecart*scale, milY-scale/2,
				milX+scale/2+ecart*scale, milY-scale/2,
				milX+scale/2+ecart*scale, milY+scale/2,
				milX-scale/2+ecart*scale, milY+scale/2);
			}
			
			if(L.tab[cell]&(1 << Nord)){//mur à gauche
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX-scale+ecart*scale*2, milY-scale,
				milX-scale/2+ecart*scale, milY-scale/2,
				milX-scale/2+ecart*scale, milY+scale/2,
				milX-scale+ecart*scale*2, milY+scale);
			}
			
			if(L.tab[cell]&(1 << Sud)){//mur à droite
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX+scale/2+ecart*scale, milY-scale/2,
				milX+scale+ecart*scale*2, milY-scale,
				milX+scale+ecart*scale*2, milY+scale,
				milX+scale/2+ecart*scale, milY+scale/2);	
			}
		
		break;
		
		case Sud:
		
			if(L.tab[cell]&(1 << Sud)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill blue\n",
				milX-scale/2-ecart*scale, milY-scale/2,
				milX+scale/2-ecart*scale, milY-scale/2,
				milX+scale/2-ecart*scale, milY+scale/2,
				milX-scale/2-ecart*scale, milY+scale/2);
			}
			
			if(L.tab[cell]&(1 << Est)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX-scale-ecart*scale*2, milY-scale,
				milX-scale/2-ecart*scale, milY-scale/2,
				milX-scale/2-ecart*scale, milY+scale/2,
				milX-scale-ecart*scale*2, milY+scale);
			}
			
			if(L.tab[cell]&(1 << Ouest)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX+scale/2-ecart*scale, milY-scale/2,
				milX+scale-ecart*scale*2, milY-scale,
				milX+scale-ecart*scale*2, milY+scale,
				milX+scale/2-ecart*scale, milY+scale/2);
			}

		break;
		
		case Ouest:
			
			if(L.tab[cell]&(1 << Ouest)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill blue\n",
				milX-scale/2-ecart*scale, milY-scale/2,
				milX+scale/2-ecart*scale, milY-scale/2,
				milX+scale/2-ecart*scale, milY+scale/2,
				milX-scale/2-ecart*scale, milY+scale/2);
			}
			
			if(L.tab[cell]&(1 << Sud)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX-scale-ecart*scale*2, milY-scale,
				milX-scale/2-ecart*scale, milY-scale/2,
				milX-scale/2-ecart*scale, milY+scale/2,
				milX-scale-ecart*scale*2, milY+scale);
			}
			
			if(L.tab[cell]&(1 << Nord)){
				fprintf(fp_to_wish,".f.c2 create polygon %d %d %d %d %d %d %d %d -outline #000000 -fill yellow\n",
				milX+scale/2-ecart*scale, milY-scale/2,
				milX+scale-ecart*scale*2, milY-scale,
				milX+scale-ecart*scale*2, milY+scale,
				milX+scale/2-ecart*scale, milY+scale/2);
			}
			
		break;
	}
	
}

void draw3D(const laby &L, const player &p){
	int cell; //la cellule à dessiner
	//cases les plus éloignées (algo du peintre)
	for(int prof=PROFONDEUR_CHAMP; prof>=0; prof--){
		for(int ecart=prof+1; ecart>0; ecart--){
			
			cell = cible(p, prof, ecart, L);
			if(cell!=-1){
				drawCell(cell,prof,ecart,L,p);
			}
			
			cell = cible(p, prof, -ecart, L);
			if(cell!=-1){
				drawCell(cell,prof,-ecart,L,p);
			}
			
		}
		cell = cible(p, prof, 0, L);//ligne du milieu
		if(cell!=-1){
			drawCell(cell,prof,0,L,p);
		}
	}
	/*
	fprintf(fp_to_wish,".f.c2 create line 200 0 200 200\n");
	fprintf(fp_to_wish,".f.c2 create line 0 100 400 100\n");
	*/
	printf("\n");
}

void drawMonstre(const laby &L, const int &scale_factor, const monstre &m, const std::string &nomMonstre){
	fprintf(fp_to_wish,".a.c create line %d %d %d %d -fill green -tag \"%s\"\n",
	m.posY*scale_factor, m.posX*scale_factor,
	m.posY*scale_factor+scale_factor, m.posX*scale_factor+scale_factor,
	nomMonstre.c_str());
	fprintf(fp_to_wish,".a.c create line %d %d %d %d -fill green -tag \"%s\"\n",
	m.posY*scale_factor, m.posX*scale_factor+scale_factor,
	m.posY*scale_factor+scale_factor, m.posX*scale_factor,
	nomMonstre.c_str());
}

void monstresAPortee(const laby &L, const int &scale_factor, const player &p, const std::vector<monstre> &m){
	//le champ de vision du joueur pour lequel il sera en mesure d'aperçevoir les monstres
	int champDeVision = 3;
	//booléen afin de savoir si le monstre doit être représenté ou non
	bool visible;
	
	int indiceMonstre;
	int indiceJoueur = p.posX * L.dimY + p.posY;
	int diffY, diffX;
	
	for(unsigned i=0; i<m.size(); i++){
		//on cherche la différence d'abscisses entre le monstre actuel et le joueur
		diffY = p.posY - m[i].posY;
		//cette fois avec les ordonnées
		diffX = p.posX - m[i].posX;
		
		indiceMonstre = m[i].posX * L.dimY + m[i].posY;
		
		visible=true;
		
		//cas Nord
		//si le monstre est sur la même colonne, dans le champ de vision et qu'il n'y a pas de mur Nord sur la case du joueur
		if((p.posY == m[i].posY) and (diffX > 0) and (diffX <= champDeVision) and (!(L.tab[indiceJoueur]&(1 << Nord)))){
			//on va, à partir de l'indiceMonstre, se rapprocher de l'indiceJoueur et vérifier la présence de murs
			while((indiceMonstre != indiceJoueur) and (visible == true)){
				if(L.tab[indiceMonstre]&(1 << Sud)){
					visible=false;
				}
				indiceMonstre += L.dimY;
			}
			//si il n'y a pas de murs alors le monstre est représenté
			if(visible==true){
				drawMonstre(L,scale_factor,m[i],m[i].name);
			}
		}
		
		//cas Sud
		if((p.posY == m[i].posY) and (diffX < 0) and (diffX >= -champDeVision) and (!(L.tab[indiceJoueur]&(1 << Sud)))){
			while((indiceMonstre != indiceJoueur) and (visible == true)){
				if(L.tab[indiceMonstre]&(1 << Nord)){
					visible=false;
				}
				indiceMonstre -= L.dimY;
			}
			if(visible==true){
				drawMonstre(L,scale_factor,m[i],m[i].name);
			}
		}
		
		//cas Est
		if((diffY < 0) and (diffY >= -champDeVision) and (p.posX == m[i].posX) and (!(L.tab[indiceJoueur]&(1 << Est)))){
			while((indiceMonstre != indiceJoueur) and (visible == true)){
				if(L.tab[indiceMonstre]&(1 << Ouest)){
					visible=false;
				}
				indiceMonstre -= 1;
			}
			if(visible==true){
				drawMonstre(L,scale_factor,m[i],m[i].name);
			}
		}
		
		//cas Ouest
		if((diffY > 0) and (diffY <= champDeVision) and (p.posX == m[i].posX) and (!(L.tab[indiceJoueur]&(1 << Ouest)))){
			while((indiceMonstre != indiceJoueur) and (visible == true)){
				if(L.tab[indiceMonstre]&(1 << Est)){
					visible=false;
				}
				indiceMonstre += 1;
			}
			if(visible==true){
				drawMonstre(L,scale_factor,m[i],m[i].name);
			}
		}	
	}//fin du for
}

void refreshLaby(const laby &L, const int &scale_factor, const player &p, const std::vector<monstre> &m){
	//On nettoie l'affichage
	fprintf(fp_to_wish,".a.c delete \"pos\"\n");
	fprintf(fp_to_wish,".f.c2 delete \"all\"\n");
	
	//on appelle les fonctions d'affichage (dessin)
	drawPlayer(scale_factor,p);
	monstresAPortee(L,scale_factor,p,m);
	draw3D(L,p);
}
