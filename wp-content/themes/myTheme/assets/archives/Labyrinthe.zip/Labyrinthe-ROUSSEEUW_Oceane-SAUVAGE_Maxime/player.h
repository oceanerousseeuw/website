/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "laby.h"

//taille du groupe d'aventuriers
#define PARTY_SIZE 4

struct aventurier{
	std::string name;
	int initiative, attaque, defense;
	int pv;
};

struct player{
	unsigned posX;
	unsigned posY;
	dir view;
	std::vector<aventurier> party;
	int sac;
};

std::vector<aventurier> initAventuriers();

void initJoueur(player &p, laby &L);

void infosJoueurs(const player &p);

#endif



