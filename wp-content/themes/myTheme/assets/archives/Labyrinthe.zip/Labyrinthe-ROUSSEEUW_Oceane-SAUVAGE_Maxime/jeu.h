/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#ifndef JEU_H
#define JEU_H

#include "laby.h"
#include "player.h"
#include "wish.h"
#include "monstre.h"

bool caseDejaVisite(std::vector<int> vec, int value);

void auxPathFinding(const laby &L, int indice, std::vector<int> temp, std::vector<int> &path);

int pathFinding(const laby &L, const player &p);

bool finPartie(const player &p, const std::vector<monstre> &m);

void regles();

void jouer(const laby &L, const int &scale_factor, player &p, std::vector<monstre> &m);

#endif
