/* Codé par ROUSSEEUW Océane et SAUVAGE Maxime */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>
#include <sys/types.h>
#include <unistd.h>
#include <fstream>

#include "laby.h"
#include "player.h"
#include "wish.h"
#include "monstre.h"
#include "jeu.h"
#include "combats.h"

int main(int argc, char **argv){
	srand(time(0)); //initialisation de la graine
	
	//initialisation du labyrinthe
	laby L;
	L.initLaby(atoi(argv[1]), atoi(argv[2]));
	
	//création de l'arbre
	std::vector<unsigned> arbre;
	initArbre(L,arbre);
	
	//création du joueur
	player p;
	initJoueur(p,L);
	
	//création des monstres
	std::vector<monstre> m;
	initMonstres(m,L);
	
	//initialisation et création de l'affichage
	initWish();
	int scale_factor = findScale(L);
	initCanvas(L,scale_factor);
	
	//afficherLaby(L);
	
	jouer(L,scale_factor,p,m);
	
	return 0;
}
