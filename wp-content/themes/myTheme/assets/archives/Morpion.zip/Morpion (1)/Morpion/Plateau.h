/* On utilise une fonction non portable pour nettoyer l'affichage,
Il faut donc savoir � l'avance sur quel SE on se trouve pour utiliser la bonne fonction */
#if defined WIN32
#define CLEAN_SCREEN "CLS"
#elif defined __linux
#define CLEAN_SCREEN "clear"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N   3 /* Taille du plateau de jeu */
#define nbPieces    3 /* Pieces a aligner pour gagner */
#define nbEssais    3 /* Nombre d'essais possibles pour qu'un joueur place son symbole */
#define codeOK  1
#define codeErreur  0



/* Les cases du plateau prennent soit '.' soit 'X' soit 'O' */
typedef enum Case{
    vide = '.',
    j1 = 'X',
    j2 = 'O',
} Case;



/* Type du joueur */
typedef enum typeJoueur{
    ORDI,
    HUMAIN,
} typeJoueur;


/* Enregistrement de la derni�re position jou�e par le joueur (x,y)
l'ordre du joueur (1 ou 2),
le symbole du joueur (X ou O),
le type du joueur (ORDI ou HUMAIN),
le score du joueur */
typedef struct infoJoueur{
    int x;
    int y;
    int ordre;
    Case symbole;
    typeJoueur type;
    int score;
} infoJoueur;


/* Signature des fonctions */

void pause();

void nettoyer();

void afficherLogo();

void afficherMenu();

void afficherRecap(infoJoueur p1, infoJoueur p2);

int choixJeu();

void afficherRegles();

void initPlateau();

void afficherPlateau();

int jouerOrdi(infoJoueur *n);

int jouerHumain(infoJoueur *n);

int testerDiago1(int x, int y);

int testerDiago2(int x, int y);

int testerHorizon(int x, int y);

int testerVertical(int x, int y);

int testerGagner(infoJoueur n);

int jouer(infoJoueur *n);

void relancer(infoJoueur p1,infoJoueur p2);

int save(infoJoueur p1, infoJoueur p2);

int load(infoJoueur p1, infoJoueur p2);

void partie(infoJoueur p1, infoJoueur p2);
