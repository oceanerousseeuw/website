/* Ce programme a �t� cr�� dans le cadre d'un devoir scolaire par ROUSSEEUW Oc�ane et SAUVAGE Maxime
durant la deuxi�me ann�e de Licence Informatique en 2015.
Il r�pond � un cahier des charges pr�cis d�livr� par les enseignants de l'ULCO. */

#include "Plateau.h"

int main(){
    int a,b,c;
    infoJoueur p1, p2;
    p1.score=0;
    p2.score=0;
    srand(time(0));
    b=rand()%2;
    c=rand()%2;
    nettoyer();
    initPlateau();
    afficherLogo();
    afficherMenu();

    /* On donne a chaque joueur leur symbole de facon aleatoire */
    if (b==0){
        p1.symbole=j1;
        p2.symbole=j2;
    } else {
        p1.symbole=j2;
        p2.symbole=j1;
    }

    /* On donne a chaque joueur un ordre de jeu de facon aleatoire */
    if (c==0){
        p1.ordre=1;
        p2.ordre=2;
    } else {
        p1.ordre=2;
        p2.ordre=1;
    }

    a = choixJeu();

    switch(a){

    case 1 : /* JCJ */

        p1.type=HUMAIN;
        p2.type=HUMAIN;
        afficherLogo();
        afficherRecap(p1,p2);
        partie(p1,p2);
        break;

    case 2 : /* JCE */

        p1.type=HUMAIN;
        p2.type=ORDI;
        afficherLogo();
        afficherRecap(p1,p2);
        partie(p1,p2);
        break;

    case 3 : /* IA vs IA */

        p1.type=ORDI;
        p2.type=ORDI;
        afficherLogo();
        afficherRecap(p1,p2);
        partie(p1,p2);
        break;

    case 4 : /* Charger une partie */

        if(!load(p1,p2)){
            nettoyer();
            printf(" --  Chargement impossible.  -- \n\n");
            pause();
            main();
        }
        break;

    case 5 : /* Regles */

        afficherRegles();
        main();
        break;

    }
    return 0;
}
