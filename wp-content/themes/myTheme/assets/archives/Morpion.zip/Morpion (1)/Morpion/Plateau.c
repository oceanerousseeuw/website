#include "Plateau.h"

/* Plateau de jeu */
Case plat[N][N];

void pause(){
    /* Fonction qui permet de marquer un temps d'arr�t */
    int c;
    printf("Appuyez 1 a 2 fois sur ENTREE pour continuer...");
    while((c = getchar()) != '\n' && c != EOF);
        getchar();
}

void nettoyer(){
    /* Fonction qui permet de nettoyer l'affichage de l'�cran */
    system(CLEAN_SCREEN);
}

void afficherLogo(){
    nettoyer();
    printf("\n");
    printf("    --------------------------------------------\n");
    printf("    |  __  __                   _              |\n");
    printf("    | |  ''  |                 (_)             |\n");
    printf("    | |  __  | ___  _ __  _ __  _  ___  _ ___  |\n");
    printf("    | | |  | || _ || '__|| '_ || || _ || '_  | |\n");
    printf("    | | |  | |||_||| |   | |_||| |||_||| | | | |\n");
    printf("    | |_|  |_||___||_|   | .__||_||___||_| |_| |\n");
    printf("    |                    | |                   |\n");
    printf("    |                    |_|         The Game. |\n");
    printf("    --------------------------------------------\n");
    printf("\n");
}

void afficherMenu(){
    printf("____________________________________________________\n");
    printf("                    Menu du jeu                     \n");
    printf("____________________________________________________\n");
    printf("\n");
    printf(" 1. Commencer une partie Joueur vs Joueur\n");
    printf("\n");
    printf(" 2. Commencer une partie Joueur vs IA\n");
    printf("\n");
    printf(" 3. Regarder une partie IA vs IA\n");
    printf("\n");
    printf(" 4. Charger une partie\n");
    printf("\n");
    printf(" 5. Regles du jeu\n");
    printf("\n");
}

void afficherRecap(infoJoueur p1, infoJoueur p2){
    nettoyer();
    afficherLogo();
    printf("()==[::::::::::>  Le Joueur %d (Humain) a pour symbole %c.\n\n", p1.ordre, p1.symbole);
    printf("()==[::::::::::>  Le Joueur %d (Humain) a pour symbole %c.\n\n", p2.ordre, p2.symbole);
    pause();
}

int choixJeu(){
    /* Retourne le choix de l'utilisateur dans le menu principal */
    int x;
    printf("Entrez le chiffre de votre choix : ");
    scanf("%d",&x);
    while (x<1 || x>5){
        nettoyer();
        afficherLogo();
        afficherMenu();
        printf("Il semblerait qu'il y ait un petit soucis technique avec votre choix.\nVeuillez saisir un autre chiffre : ");
        scanf("%d",&x);
    }
    return (x);
}

void afficherRegles(){
    nettoyer();
    afficherLogo();
    printf("Les joueurs inscrivent tour a tour leur symbole\nsur une grille de taille predefinie (ici %d x %d).\n\nLe premier joueur qui parvient\na aligner un nombre de symboles\nlui aussi predefinie (ici %d pieces alignees)\nsoit horizontalement, soit verticalement,\nsoit diagonalement, gagne la partie.\n", N, N, nbPieces);
    printf("\n-----------------------------------------------\n");
    pause();
}

void initPlateau(){
    /* Initialise le plateau avec des '.' */
    int i, j;
    for(i=0;i<N;i++){
        for(j=0;j<N;j++){
            plat[i][j]= vide;
        }
    }
}

void afficherPlateau(){
    int i,j;
    int tiret;
    printf("   |");
    for(i=0;i<N;i++){
        printf("%3d",i);
    }
    tiret=5+(3*N);
    printf("\n");
    for(i=0;i<tiret;i++){
        printf("-");
    }
    printf("\n");
    for(i=0;i<N;i++){
        printf("%2d |",i);
        for(j=0;j<N;j++){
            printf("%3c",plat[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<tiret;i++){
        printf("_");
    }
    printf("\n");
    for(i=0;i<tiret;i++){
        printf("_");
    }
    printf("\n");
    printf("\n");
}

int jouerOrdi(infoJoueur *n){
    /* Fonction qui prend en param�tre des pointeurs afin de modifier le contenu de la structure qu'ils pointent
    L (lignes) et C (colonnes) sont g�n�r�s al�atoirement. */

    srand(time(0));
    int L = rand()%(N);
	int C = rand()%(N);
	if (plat[L][C] != vide){
        /* x et y repr�sentent les coordonn�es du dernier point jouer pour un joueur (inclus dans la structure infoJoueur) */
        (*n).x=L;
	    (*n).y=C;
        return codeErreur;
	} else {
	    /* Si la case est vide on y met le symbole du joueur. */
	    plat[L][C]=(*n).symbole;
	    (*n).x=L;
	    (*n).y=C;
	    return codeOK;
	}
}

int jouerHumain(infoJoueur *n){
    /* M�me fonction que jouerOrdi mais cette fois pour un humain. */
    int L, C;
    printf("\nChoisissez une ligne : \n");
    scanf("%d",&L);
    while(L>=N || L<0){
        /* On ne tient pas compte, dans le nombre d'essais autoris�s, d'une ligne/colonne inexistante. On demande � resaisir. */
        printf("\nChoisissez une ligne valide : \n");
        scanf("%d",&L);
    }

    printf("\nChoisissez une colonne : \n");
    scanf("%d",&C);
    while(C>=N || C<0){
        printf("\nChoisissez une colonne valide : \n");
        scanf("%d",&C);
    }
    if (plat[L][C] != vide){
        (*n).x=L;
	    (*n).y=C;
        return codeErreur;
	} else {
	    plat[L][C]=(*n).symbole;
	    (*n).x=L;
	    (*n).y=C;
	    return codeOK;
	}
}

int testerDiago1(int x, int y){
	int cpt=1;
	int L1=x, C1=y;
	int L2=L1, C2=C1;
	while (plat[L1][C1] == plat[L1+1][C1+1]){
        L1++;
        C1++;
		cpt++;
	}
	while (plat[L2][C2] == plat[L2-1][C2-1]){
        L2--;
        C2--;
		cpt++;
	}
	return cpt;
}

int testerDiago2(int x, int y){
	int cpt=1;
	int L1=x, C1=y;
	int L2=L1, C2=C1;
	while (plat[L1][C1] == plat[L1+1][C1-1]){
        L1++;
        C1--;
		cpt++;
	}
	while (plat[L2][C2] == plat[L2-1][C2+1]){
        L2--;
        C2++;
		cpt++;
	}
	return cpt;
}

int testerHorizon(int x, int y){
	int cpt=1;
	int L1=x, C1=y;
	int L2=L1, C2=C1;
	while (plat[L1][C1] == plat[L1+1][C1]){
        L1++;
		cpt++;
	}
	while (plat[L2][C2] == plat[L2-1][C2]){
        L2--;
		cpt++;
	}
	return cpt;
}

int testerVertical(int x, int y){
	int cpt=1;
	int L1=x, C1=y;
	int L2=L1, C2=C1;
	while (plat[L1][C1] == plat[L1][C1-1]){
        C1--;
		cpt++;
	}
	while (plat[L2][C2] == plat[L2][C2+1]){
        C2++;
		cpt++;
	}
	return cpt;
}

int testerGagner(infoJoueur n){
    /* On test avec les derni�res coordonn�es du point jou� par le joueur
    toutes les directions pour gagner.
    Si l'une d'elles compte et retourne une valeur �gale au nombre de pi�ces pour gagner,
    la fonction testerGagner va retourner codeOK et la partie s'ach�vera.

    Cette fonction ne prend pas de pointeurs car elle ne modifie pas de valeurs. */
    int a=n.x, b=n.y;
    if (testerDiago1(a,b) == nbPieces){
        return codeOK;
    } else {
        if (testerDiago2(a,b) == nbPieces){
            return codeOK;
        } else {
            if (testerHorizon(a,b) == nbPieces){
                return codeOK;
            } else {
                if (testerVertical(a,b) == nbPieces){
                    return codeOK;
                } else {
                    return codeErreur;
                }
            }
        }
    }
}

int jouer(infoJoueur *n){
    /* Cette fonction appelle les bonnes fonctions pour jouer un coup (placer une pi�ce sur le plateau).
    Elle utilise des pointeurs car elle modifie des valeurs par le biais d'autres fonctions. */
    int cpt = 0;
    int res;
    if ((*n).type == 0){
        /* Selon le type du joueur (0 pour ORDI et 1 pour HUMAIN (cf. enum)) elle appelle la fonction ad�quate. */
        res = jouerOrdi(n);
        cpt++;
        while ((res == codeErreur) && (cpt < nbEssais)){
            /* On autorise le joueurs � se tromper un certain nombre de fois. */
            nettoyer();
            afficherPlateau();
            /* En plus de retourner un code, elle affiche un message si le joueur a pu jouer. */
            printf("    Au tour du joueur %d de jouer\n",(*n).ordre);
            printf("    -----------------------------\n");
            printf(" * Mmm... C'est embarassant. La case (%d,%d) deja prise... * \n",(*n).x,(*n).y);
            printf("                  %d essai(s) restant(s)\n\n",nbEssais-(cpt));
            pause();
            res = jouerOrdi(n);
            cpt++;
        }
        if (res == codeOK){
            nettoyer();
            afficherPlateau();
            printf("    Au tour du joueur %d de jouer\n",(*n).ordre);
            printf("    -----------------------------\n");
            printf(" * Le joueur %d joue a la case (%d,%d). *\n",(*n).ordre,(*n).x,(*n).y);
            printf("\n");
            /* Dans le cas d'un type ORDI, on marque une pause afin que l'utilisateur sache o� il a jouer. */
            pause();
            return codeOK;
        } else {
            return codeErreur;
        }

    } else {
        res = jouerHumain(n);
        cpt++;
        while ((res == codeErreur) && (cpt < nbEssais)){
            nettoyer();
            afficherPlateau();
            printf("    Au tour du joueur %d de jouer\n",(*n).ordre);
            printf("    -----------------------------\n");
            printf(" * Mmm... C'est embarassant. La case (%d,%d) deja prise... * \n",(*n).x,(*n).y);
            printf("                  %d essai(s) restant(s)\n\n",nbEssais-(cpt));
            res = jouerHumain(n);
            cpt++;
        }
        if (res == codeOK){
            /* On part du principe que l'utilisateur sait o� il met sa pi�ce et donc
             pour �viter la redondance on ne marque pas de pause pour lui. */
            return codeOK;
        } else {
            return codeErreur;
        }
    }
}

void relancer(infoJoueur p1,infoJoueur p2){
    /* Cette fonction affiche le score des joueurs et propose de relancer une partie. */
    int a;
    printf("\n            joueur %d | joueur %d\n",p1.ordre,p2.ordre);
    printf("    ---------------------------\n");
    printf("    Score : %4d     | %4d\n\n",p1.score,p2.score);
    printf("______________________________________________\n");
    printf("  ## Souhaitez vous rejouer une partie ? ##\n");
    printf("(Les parametres de la partie seront conserves)\n");
    printf("            1. Oui      2. Non\n");
    printf("\nVotre choix : ");
    scanf("%d",&a);
    while (a<1 || a>2){
        printf("Il semblerait qu'il y ait un petit soucis technique avec votre choix.\nVeuillez saisir un autre chiffre : ");
        scanf("%d",&a);
    }

    switch(a){

    case 1 :
        /* Si oui on remet � jour le plateau et on relance la fonction partie.
        Les structs p1 et p2 conserve leurs param�tres car ils sont initialis�s avant la fonction partie
        dans le cadre d'un lancement de partie normal. */
        initPlateau();
        partie(p1,p2);
        break;

    case 2 :
        /* Sinon on retourne au menu principal. */
        main();
        break;
    }
}

int save(infoJoueur p1, infoJoueur p2){
    /* Fonction qui sauvegarde la partie actuelle */
    int i,j;
    FILE *f = fopen("save.txt","w");
    if(f){
        fprintf(f,"%d",N);
        for(i=0;i<N;i++){
            for(j=0;j<N;j++){
                fprintf(f,"%c",plat[i][j]);
            }
        }
        fprintf(f," %d %d %d %c %d %d ",p1.x,p1.y,p1.ordre,p1.symbole,p1.type,p1.score);
        fprintf(f," %d %d %d %c %d %d ",p2.x,p2.y,p2.ordre,p2.symbole,p2.type,p2.score);
        fclose(f);
        return codeOK;
    } else {
        return codeErreur;
    }

}

int load(infoJoueur p1, infoJoueur p2){
    /* Fonction qui charge l'unique sauvegarde si elle existe */
    int i,j,T;
    FILE *f = fopen("save.txt","r");
    if(f){
        fscanf(f,"%d",&T);
        if(T==N){
            for(i=0;i<N;i++){
                for(j=0;j<N;j++){
                    fscanf(f,"%c",&plat[i][j]);
                }
            }
            fscanf(f," %d %d %d %c %d %d ",&p1.x,&p1.y,&p1.ordre,&p1.symbole,&p1.type,&p1.score);
            fscanf(f," %d %d %d %c %d %d ",&p2.x,&p2.y,&p2.ordre,&p2.symbole,&p2.type,&p2.score);
            fclose(f);
            partie(p1,p2);
        } else {
            return codeErreur;
        }
    } else {
        return codeErreur;
    }
}

void partie(infoJoueur p1, infoJoueur p2){
    /* Fonction qui appelle les autres fonctions n�cessairent au d�roulement du jeu.
    Se relance tant qu'il n'y a pas d'issues telles que : le joueur n'a pas pu jou� ou le joueur a gagn�. */
    nettoyer();
    int res,sauv;
    afficherPlateau();
    /* Si p1 est le joueur qui joue en premier alors c'est � lui. */
    if (p1.ordre==1){
        /* Cas 1 - Le premier joueur joue */
        printf("    Au tour du joueur %d de jouer\n",p1.ordre);
        printf("    -----------------------------\n");
        res = jouer(&p1);
        if (res==codeErreur){
            /* Cas 1.1 - Le premier joueur n'a pas pu jou� */
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d n'a pas pu jouer.  --\n",p1.ordre);
            printf("--        Fin de la partie.       --\n");
            printf("************************************\n");
            /* Gagner car l'autre n'a pas pu jouer... bof bof...
            Le score de l'autre joueur n'augmente pas et on propose � l'utilisateur de rejouer */
            relancer(p1,p2);
        }
        res = testerGagner(p1);
        if (res==codeOK){
            /* Cas 1.2 - Le premier joueur a gagn� */
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d gagne la partie !  --\n",p1.ordre);
            printf("--         Felicitations !        --\n");
            printf("************************************\n");
            /* Son score augmente et on propose � l'utilisateur de rejouer */
            p1.score++;
            relancer(p1,p2);
        }
        /* Cas 1 - Le deuxi�me joueur joue */
        nettoyer();
        afficherPlateau();
        printf("    Au tour du joueur %d de jouer\n",p2.ordre);
        printf("    -----------------------------\n");
        res = jouer(&p2);
        if (res==codeErreur){
            /* Cas 1.3 - Le deuxi�me joueur n'a pas pu jouer */
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d n'a pas pu jouer.  --\n",p2.ordre);
            printf("--        Fin de la partie.       --\n");
            printf("************************************\n");
            relancer(p1,p2);
        }
        res = testerGagner(p2);
        if (res==codeOK){
            /* Cas 1.4 - Le deuxi�me joueur a gagn� */
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d gagne la partie !  --\n",p2.ordre);
            printf("--         Felicitations !        --\n");
            printf("************************************\n");
            p2.score++;
            relancer(p1,p2);
        }



    } else {



        /* Cas 2 - Le deuxi�me joueur joue */
        printf("    Au tour du joueur %d de jouer\n",p2.ordre);
        printf("    -----------------------------\n");
        res = jouer(&p2);
        if (res==codeErreur){
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d n'a pas pu jouer.  --\n",p2.ordre);
            printf("--        Fin de la partie.       --\n");
            printf("************************************\n");
            relancer(p1,p2);
        }
        res = testerGagner(p2);
        if (res==codeOK){
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d gagne la partie !  --\n",p2.ordre);
            printf("--         Felicitations !        --\n");
            printf("************************************\n");
            p2.score++;
            relancer(p1,p2);
        }
        /* Cas 2 - Le premier joueur joue */
        nettoyer();
        afficherPlateau();
        printf("    Au tour du joueur %d de jouer\n",p1.ordre);
        printf("    -----------------------------\n");
        res = jouer(&p1);
        if (res==codeErreur){
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d n'a pas pu jouer.  --\n",p1.ordre);
            printf("--        Fin de la partie.       --\n");
            printf("************************************\n");
            relancer(p1,p2);
        }
        res = testerGagner(p1);
        if (res==codeOK){
            nettoyer();
            afficherPlateau();
            printf("\n************************************\n");
            printf("-- Le joueur %d gagne la partie !  --\n",p1.ordre);
            printf("--         Felicitations !        --\n");
            printf("************************************\n");
            p1.score++;
            relancer(p1,p2);
        }
    }
    nettoyer();
    afficherPlateau();
    /* Un tour comprend le coup de p1 et de p2.
    A la fin de chaque tour on propose � l'utilisateur de sauvegarder sa partie actuelle. */
    printf("________________________________________________\n");
    printf(" ## Souhaitez vous SAUVEGARDER votre partie ? ##\n");
    printf("             1. Oui        2. Non\n\n");
    printf("Votre choix : ");
    scanf("%d",&sauv);
    while(sauv<1 || sauv>2){
        printf("Il semblerait qu'il y ait un petit soucis technique avec votre choix.\nVeuillez saisir un autre chiffre : ");
        scanf("%d",&sauv);
    }
    if(sauv==1){
        if(save(p1,p2)){
            printf("Sauvegarde reussie.\n\n");
        }else{
            printf("Echec de la sauvegarde.\n\n");
        }
        pause();
    }
    /* On relance la partie. */
    partie(p1,p2);
}

