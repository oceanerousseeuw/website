/* Ce programme a �t� cr�� dans le cadre d'un devoir scolaire par ROUSSEEUW Oc�ane et SAUVAGE Maxime
durant la deuxi�me ann�e de Licence Informatique en 2015.
Il r�pond � un cahier des charges pr�cis d�livr� par les enseignants de l'ULCO. */

#include "Bibli.h"

int main(){
    srand(time(NULL));
    int a, b;
    Jeu *j = malloc(sizeof(Jeu));
    int i, nbP, nbM, nbF;
    int Taille[3]; // 3 tailles de plateaux differentes pr�d�finies
    Taille[0] = 15;
    Taille[1] = 20;
    Taille[2] = 25;

    do{
        afficherLogo();
        afficherMenu();
        a = choixJeu();

        if(a != 3){

            switch (a){

            case 1: // Lancement d'une partie
                afficherLogo();
                afficherMenu2();
                b = choixJeu2();

                i = entierAlea_a_b(0,3); // Taille al�atoire
                nbM = Taille[i] - 3; // Nombre de murs < taille d'un c�t�  (�vite des probl�mes de g�n�ration)
                nbP = 25; // Nombre de pi�ces ne varie pas

                switch (b){

                case 1: // Facile (peu de fantomes)
                    nbF = 1;
                    break;

                case 2: // Moyen
                    nbF = 3;
                    break;

                case 3: // Difficile (plus de fantomes)
                    nbF = 5;
                    break;
                }

                j = creerJeu(Taille[i], Taille[i], nbP, nbM, nbF); // On cr�er le jeu
                jouer(j); // On joue !

                break;

            case 2:
                afficherRegles();
                break;
            }
        }
    }while(a != 3);

    return 0;
}

