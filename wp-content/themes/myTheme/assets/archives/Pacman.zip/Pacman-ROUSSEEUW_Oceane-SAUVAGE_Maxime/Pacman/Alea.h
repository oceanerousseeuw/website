/* Signature des fonctions */

int entierAlea_a_b(const int a, const int b);

void ajouterPieces(Plateau *p);

