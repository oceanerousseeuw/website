typedef enum Case{mur,vide,piece,humain,fantome}Case;

typedef struct Plateau{
    int tailleX;
    int tailleY;
    int nbPieces;
    int nbMurs;
    Case **grille;
}Plateau;

/* Signature des fonctions */

Plateau * creerPlateau(int a,int b,int c,int d);

void afficherPlateau(const Plateau *p);
