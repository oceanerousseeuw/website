#if defined WIN32

    #define CLEAN_SCREEN "CLS"
    #include <windows.h>

    #define ANSI_COLOR_RED
    #define ANSI_COLOR_GREEN
    #define ANSI_COLOR_YELLOW
    #define ANSI_COLOR_BLUE
    #define ANSI_COLOR_MAGENTA
    #define ANSI_COLOR_CYAN
    #define ANSI_COLOR_RESET

#elif defined __linux

    #define CLEAN_SCREEN "clear"
    #include <unistd.h>

    #define ANSI_COLOR_RED     "\x1b[31m"
    #define ANSI_COLOR_GREEN   "\x1b[32m"
    #define ANSI_COLOR_YELLOW  "\x1b[33m"
    #define ANSI_COLOR_BLUE    "\x1b[34m"
    #define ANSI_COLOR_MAGENTA "\x1b[35m"
    #define ANSI_COLOR_CYAN    "\x1b[36m"
    #define ANSI_COLOR_RESET   "\x1b[0m"

#endif


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "Menu.h"
#include "Plateau.h"
#include "Alea.h"
#include "Mur.h"
#include "Humain.h"
#include "Jeu.h"
#include "ListeChainee.h"


#define nbEssais 100
// Nombre d'essais autoris�s (utilis� pour chercher le pt de d�part d'un mur et les dp�lacements des fantomes)


