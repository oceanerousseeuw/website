void pause();

void afficherLogo();

void afficherMenu();

void afficherMenu2();

int choixJeu();

int choixJeu2();

void afficherRegles();
