#include "Bibli.h"

int voisinsSansMurs(const Plateau *p, int x, int y){
    // On v�rifie que les cases adjacentes ne sont pas des bords

    // haut
    if(p->grille[x-1][y] == mur && x-1 != 0)
        return 0;

    // gauche
    if(p->grille[x][y-1] == mur && y-1 != 0)
        return 0;

    // bas
    if(p->grille[x+1][y] == mur && x+1 != p->tailleX-1)
        return 0;

    // droite
    if(p->grille[x][y+1] == mur && y+1 != p->tailleY-1)
        return 0;


    // On v�rifie aussi les diagonales qui peuvent bloquer le jouer != d'un coin

    // haut + gauche
    if(p->grille[x-1][y-1] == mur && x-1 != 0 && y-1 != 0)
        return 0;

    // bas + gauche
    if(p->grille[x+1][y-1] == mur && x+1 != p->tailleX-1 && y-1 != 0)
        return 0;

    // bas + droite
    if(p->grille[x+1][y+1] == mur && x+1 != p->tailleX-1 && y+1 != p->tailleY-1)
        return 0;

    // haut + droite
    if(p->grille[x-1][y+1] == mur && x-1 != 0 && y+1 != p->tailleY-1)
        return 0;

    return 1;
}

int estUnCoin(const Plateau *p, int x, int y){
    // On v�rifie que la case n'a pas de mur autour d'elle

    if(p->grille[x-1][y] == mur && p->grille[x][y-1] == mur)
        return 1;

    if(p->grille[x+1][y] == mur && p->grille[x][y-1] == mur)
        return 1;

    if(p->grille[x][y+1] == mur && p->grille[x+1][y] == mur)
        return 1;

    if(p->grille[x][y+1] == mur && p->grille[x-1][y] == mur)
        return 1;

    return 0;
}

void rechercherPtDepart(const Plateau *p, int *x, int *y, int *dirX, int *dirY){
    int a, cptErr = 0;
    a=rand()%4; // Va d�finir le c�t� de d�part

    switch(a){

    case 0:

        // c�t� haut

        *x = 1; // On connait donc le x
        *dirX = 1; // On connait donc la direction que l'on incr�mentera
        *dirY = 0;

        do{
            *y = entierAlea_a_b(3,p->tailleY-4);
            /* On r�duit les bornes pour ne pas qu'il y ai un mur d�j� existant trop long et trop proche
             du c�t� en question emp�chant la cr�ation d'un point de d�part et provoquant une boucle infinie */

             cptErr++;
             if(cptErr > nbEssais)
                /* On a mit en place une s�curit� pour �viter un autre cas de boucles infinies, si la
                condition est vraie on relance la fonction en �sperant avoir un des 3 c�t�s restants */
                rechercherPtDepart(p,x,y,dirX,dirY);

        }while(estUnCoin(p,*x,*y) || !voisinsSansMurs(p,*x,*y) || p->grille[*x][*y] != vide);

        break;

    case 1:

        // c�t� gauche

        *y = 1;
        *dirX = 0;
        *dirY = 1;

        do{
            *x = entierAlea_a_b(3,p->tailleX-4);

            cptErr++;
            if(cptErr > nbEssais)
                rechercherPtDepart(p,x,y,dirX,dirY);

        }while(estUnCoin(p,*x,*y) || !voisinsSansMurs(p,*x,*y) || p->grille[*x][*y] != vide);

        break;

    case 2:

        // c�t� bas

        *x = p->tailleX-2;
        *dirX = -1;
        *dirY = 0;

        do{
            *y = entierAlea_a_b(3,p->tailleY-4);

            cptErr++;
            if(cptErr > nbEssais)
                rechercherPtDepart(p,x,y,dirX,dirY);

        }while(estUnCoin(p,*x,*y) || !voisinsSansMurs(p,*x,*y) || p->grille[*x][*y] != vide);

        break;

    case 3:

        // c�t� droit

        *y = p->tailleY-2;
        *dirX = 0;
        *dirY = -1;

        do{
            *x = entierAlea_a_b(3,p->tailleX-4);

            cptErr++;
            if(cptErr > nbEssais)
                rechercherPtDepart(p,x,y,dirX,dirY);

        }while(estUnCoin(p,*x,*y) || !voisinsSansMurs(p,*x,*y) || p->grille[*x][*y] != vide);

        break;

    }
}

int rechercherPtDepartMurSansBords(const Plateau *p, int *x, int *y, int *dirX, int *dirY){
    int cptErr = 0;

    do{
        *x = entierAlea_a_b(3,p->tailleX-4);
        *y = entierAlea_a_b(3,p->tailleY-4);
        *dirX = rand()%2;
        if(*dirX == 0){
            *dirY = 1;
        }else{
            *dirY = 0;
        }

        cptErr++; // S�curit� anti boucles infinies
        if(cptErr > nbEssais)
            return 0;

    }while(estUnCoin(p,*x,*y) || !voisinsSansMurs(p,*x,*y) || p->grille[*x][*y] != vide);

    return 1;
}

int tailleMax(const Plateau *p, int x, int y, int dirX, int dirY){
    int taille = 0;

    while(p->grille[x][y] == vide && ((x != 0 || x != p->tailleX-2) && (y != 0 || y != p->tailleY-2)) && !estUnCoin(p,x,y) && voisinsSansMurs(p,x,y)){
        x += dirX;
        y += dirY;
        taille++;
    }

    return taille;
}

void construireUnMur(const Plateau *p, int x, int y, int dirX, int dirY, int longueurMax){
    int taille, cpt = 0;
    taille = entierAlea_a_b(1, longueurMax);

    while(cpt < taille){
        p->grille[x][y] = mur;
        x += dirX;
        y += dirY;
        cpt++;
    }
}

void ajouterMurs(Plateau *p){
    int x, y, dirX, dirY, taille, cpt=0, a;

    if(p->nbMurs > 0){

        do{
            a = rand()%2;

            switch(a){

            case 0:
                // Mur avec d�part = bord
                rechercherPtDepart(p,&x,&y,&dirX,&dirY);
                taille = tailleMax(p,x,y,dirX,dirY);
                construireUnMur(p,x,y,dirX,dirY,taille);
                break;

            case 1:
                // Mur avec d�part != bord
                if(!rechercherPtDepartMurSansBords(p,&x,&y,&dirX,&dirY))
                    ajouterMurs(p);
                taille = tailleMax(p,x,y,dirX,dirY);
                construireUnMur(p,x,y,dirX,dirY,taille);
                break;
            }

            cpt++;

        }while(cpt < p->nbMurs);

    }
}
