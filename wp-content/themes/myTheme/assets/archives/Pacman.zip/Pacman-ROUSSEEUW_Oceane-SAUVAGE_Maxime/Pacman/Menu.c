#include "Bibli.h"

void pause(){
    /* Fonction qui permet de marquer un temps d'arr�t */
    int c;
    printf("\nAppuyez sur ENTREE pour continuer...");
    while((c = getchar()) != '\n' && c != EOF);
        getchar();
}

void afficherLogo(){
    system(CLEAN_SCREEN);
    printf("\n");
    printf("    ----------------------------------------------------------\n");
    printf("    |  _______  _______  _______  __   __  _______  __    _  |\n");
    printf("    | |       ||   _   ||       ||  |_|  ||   _   ||  |  | | |\n");
    printf("    | |    _  ||  |_|  ||       ||       ||  |_|  ||   |_| | |\n");
    printf("    | |   |_| ||       ||       ||       ||       ||       | |\n");
    printf("    | |    ___||       ||      _||       ||       ||  _    | |\n");
    printf("    | |   |    |   _   ||     |_ | ||_|| ||   _   || | |   | |\n");
    printf("    | |___|    |__| |__||_______||_|   |_||__| |__||_|  |__| |\n");
    printf("    |                                                        |\n");
    printf("    |                                               Da Game. |\n");
    printf("    ----------------------------------------------------------\n");
    printf("\n");
}

void afficherMenu(){
    printf("________________________________________________________________\n");
    printf("                          Menu du jeu                           \n");
    printf("________________________________________________________________\n");
    printf("\n");
    printf(" 1. Commencer une partie\n");
    printf("\n");
    printf(" 2. Regles du jeu\n");
    printf("\n");
    printf(" 3. Quitter\n");
    printf("\n");
}

void afficherMenu2(){
    printf("________________________________________________________________\n");
    printf("                   Choisissez une difficulte                    \n");
    printf("________________________________________________________________\n");
    printf("\n");
    printf(" 1. Facile\n");
    printf("\n");
    printf(" 2. Moyen\n");
    printf("\n");
    printf(" 3. Difficile\n");
    printf("\n");
}

int choixJeu(){
    /* Retourne le choix de l'utilisateur dans le menu principal */
    int x;
    printf("Entrez le chiffre de votre choix : ");
    scanf("%d",&x);
    while (x<1 || x>3){
        system(CLEAN_SCREEN);
        afficherLogo();
        afficherMenu();
        printf("Il semblerait qu'il y ait un petit soucis technique avec votre choix.\nVeuillez saisir un autre chiffre : ");
        scanf("%d",&x);
    }
    return (x);
}

int choixJeu2(){
    /* Retourne le choix de l'utilisateur dans le choix de difficult� */
    int x;
    printf("Entrez le chiffre de votre choix : ");
    scanf("%d",&x);
    while (x<1 || x>3){
        system(CLEAN_SCREEN);
        afficherLogo();
        afficherMenu2();
        printf("Il semblerait qu'il y ait un petit soucis technique avec votre choix.\nVeuillez saisir un autre chiffre : ");
        scanf("%d",&x);
    }
    return (x);
}

void afficherRegles(){
    system(CLEAN_SCREEN);
    afficherLogo();
    printf("A l'aide de votre avatar (H) deplacez vous sur le plateau en evitant\nles fantomes (F) avec les touches Z,Q,S,D.\nLa partie s'arrete lorsque il n'y a plus de pieces (*) sur le plateau.\n\nLa difficulte influe sur le nombre de fantomes presents.\nIl existe 3 tailles de plateau differentes (petite, moyenne, grande).\nLe nombre de murs est generes selon la taille du plateau.\nLe nombre de pieces est constant (le plus haut score est donc 25).\n");
    printf("\n-----------------------------------------------");
    pause();
}
