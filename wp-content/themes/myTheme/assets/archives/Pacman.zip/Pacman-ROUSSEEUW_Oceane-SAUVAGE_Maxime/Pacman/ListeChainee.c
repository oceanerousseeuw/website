#include "Bibli.h"

int compareCoups(const Coup *c1, const Coup *c2){
    // On cherche � comparer si 2 coups sont les m�mes, on retourne 1 si c'est vrai
    if(c1->posX == c2->posX && c1->posY == c2->posY)
        return 1;
    return 0;
}

int coupExiste(const Coup *liste, const Coup *choix){
    // On passe la premi�re valeure qui est la position actuelle dans notre liste
    liste = liste->next;
    // On v�rifie que le choix est dans la liste
    while(liste){
        if(compareCoups(liste,choix))
            return 1;
        liste = liste->next;
    }

    return 0;
}

void afficherCoupsPossibles(const Coup *c){
    Coup *temp = c->next;

    printf("\nDirections possibles : ");

    while(temp){

        if(temp->posX > c->posX)
            printf(" Bas (S) ");

        if(temp->posX < c->posX)
            printf(" Haut (Z) ");

        if(temp->posY > c->posY)
            printf(" Droite (D) ");

        if(temp->posY < c->posY)
            printf(" Gauche (Q) ");

        temp = temp->next;
    }

    printf("\n");

}

void ajoutFin(Coup **liste, int x, int y){
    // Fonction qui ajoute un Coup � la fin d'une liste
    Coup *nouveau = malloc(sizeof(Coup));
    nouveau->posX = x;
    nouveau->posY = y;
    nouveau->next = NULL;

    Coup *temp = *liste;

    while(temp->next){
        temp = temp->next;
    }

    temp->next = nouveau;
}

Coup * choixCoup(Jeu *j){
    // Seule fonction o� l'on peut comparer avec les �l�ments de la grille

    // le 1er �l�ment de la liste est la position actuelle du joueur
    Coup *liste = malloc(sizeof(Coup));
    liste->posX = j->h->posX;
    liste->posY = j->h->posY;
    liste->next = NULL;

    // on peut aller dans 4 directions, il faut v�rifier pour chacunes de ces directions si les conditions sont remplies, si oui on l'ajoute � la liste chain�e
    if(j->p->grille[j->h->posX+1][j->h->posY] != mur)
        ajoutFin(&liste,j->h->posX+1,j->h->posY);

    if(j->p->grille[j->h->posX-1][j->h->posY] != mur)
        ajoutFin(&liste,j->h->posX-1,j->h->posY);

    if(j->p->grille[j->h->posX][j->h->posY+1] != mur)
        ajoutFin(&liste,j->h->posX,j->h->posY+1);

    if(j->p->grille[j->h->posX][j->h->posY-1] != mur)
        ajoutFin(&liste,j->h->posX,j->h->posY-1);

     // initialisation du coup retourn� - pour l'instant c'est la position actuelle du joueur
    Coup *choix = malloc(sizeof(Coup));
    char dir;

    afficherCoupsPossibles(liste);

    do{

        choix->posX = j->h->posX;
        choix->posY = j->h->posY;
        choix->next = NULL;

        scanf("%c",&dir);

        if(dir == 'z')
            choix->posX = j->h->posX-1;

        if(dir == 'q')
            choix->posY = j->h->posY-1;

        if(dir == 's')
            choix->posX = j->h->posX+1;

        if(dir == 'd')
            choix->posY = j->h->posY+1;

    }while(!coupExiste(liste,choix));

    return choix;
}
