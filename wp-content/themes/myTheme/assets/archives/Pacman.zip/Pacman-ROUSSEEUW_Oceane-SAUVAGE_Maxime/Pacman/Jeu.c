#include "Bibli.h"


void afficherJeu(const Jeu *j){
    afficherPlateau(j->p);
    printf("\n");
    afficherHumain(j->h);
}

Jeu * creerJeu(int tX, int tY, int nbP, int nbM, int nbF){
    Jeu *j = malloc(sizeof(Jeu));

    j->p = creerPlateau(tX,tY,nbP,nbM);
    j->h = creerHumain();
    j->nbF = nbF;
    j->f = malloc(j->nbF*sizeof(Fantome));

    return j;
}

void initialiserJeu(Jeu *j){
    // Fonction qui place l'Humain et les fantomes al�atoirement
    int x, y, i = 0, cpt = j->nbF;

    do{

        x = entierAlea_a_b(1,j->p->tailleX-2);
        y = entierAlea_a_b(1,j->p->tailleY-2);

    }while(j->p->grille[x][y] != vide);

    j->h->posX = x;
    j->h->posY = y;

    j->p->grille[x][y] = humain;

    if(j->nbF > 0){

        do{

            do{
                x = entierAlea_a_b(1,j->p->tailleX-2);
                y = entierAlea_a_b(1,j->p->tailleY-2);

            }while(j->p->grille[x][y] != vide);

            j->f[i].posX = x;
            j->f[i].posY = y;

            j->p->grille[x][y] = fantome;

            i++;
            cpt--;

        }while(cpt > 0);
    }

}

int jouerCoup(Jeu *j, Coup *c){
    if(j->p->grille[c->posX][c->posY] == piece){
        j->h->score++;
        j->p->nbPieces--;
    }

    if(j->p->grille[c->posX][c->posY] == fantome){
        return 0; // On pose une condition de sortie qui facilitera l'affichage de victoire ou d�faite
    }

    if(j->h->score >= j->h->record){
        sauverRecord(j->h); // On sauvegarde le nouveau score en tant que record
        j->h->record = j->h->score; // Le score ne peut aps �tre plus �lev� que le record r�cup�r� en tout d�but de partie
    }

    j->p->grille[j->h->posX][j->h->posY] = vide;

    j->h->posX = c->posX;
    j->h->posY = c->posY;

    j->p->grille[j->h->posX][j->h->posY] = humain;

    return 1;
}

int bougerFantomesAleatoirement(Jeu *j){
    int i, a, x, y, cptEr;

    if(j->nbF > 0){

        for(i=0; i<j->nbF; i++){ // Pour chaque fantome

            cptEr = 0; // Le compteur revient � 0

            do{

                x = j->f[i].posX;
                y = j->f[i].posY;

                a = rand()%4; // On cherche 1 direction parmis les 4

                switch (a){

                case 0:
                    x++;
                    break;

                case 1:
                    x--;
                    break;

                case 2:
                    y++;
                    break;

                case 3:
                    y--;
                    break;
                }

                cptEr++;

            }while((j->p->grille[x][y] == mur || j->p->grille[x][y] == piece || j->p->grille[x][y] == fantome) && cptEr < nbEssais);

            if(cptEr >= nbEssais){
                // Si on a d�pass� le nombre d'essais autoris�s, le fantome ne bougera pas, �vite les boucles infinies
                x = j->f[i].posX;
                y = j->f[i].posY;
            }

            j->p->grille[j->f[i].posX][j->f[i].posY] = vide;

            j->f[i].posX = x;
            j->f[i].posY = y;

            if(j->p->grille[j->f[i].posX][j->f[i].posY] == humain){
                j->p->grille[x][y] = fantome;
                return 0; // Condition de sortie : si le fantome rencontre l'humain c'est perdu
            }

            j->p->grille[x][y] = fantome;
        }
    }

    return 1;
}

void jouer(Jeu *j){
    initialiserJeu(j);

    Coup *c = malloc(sizeof(Coup));

    do{
        system(CLEAN_SCREEN);
        afficherJeu(j);

        c = choixCoup(j);
        if(!jouerCoup(j,c) || !bougerFantomesAleatoirement(j)){
            printf(" *********************\n");
            printf(" *     GAME OVER     *\n");
            printf(" *********************\n");
            pause();
            return;
        }

    }while(j->p->nbPieces != 0);

    sauverRecord(j->h);
    system(CLEAN_SCREEN);
    afficherJeu(j);
    printf("\n *********************\n");
    printf(" *      VICTOIRE     *\n");
    printf(" *********************\n");
    pause();
    return;
}

