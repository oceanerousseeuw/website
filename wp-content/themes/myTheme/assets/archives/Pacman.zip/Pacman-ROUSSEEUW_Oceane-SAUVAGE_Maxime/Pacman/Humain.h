typedef struct Humain{
    char nom[20];
    int score;
    int record;
    int posX;
    int posY;
}Humain;


/* Signature des fonctions */

void afficherHumain(const Humain *h);

void recupererRecord(Humain *h);

void sauverRecord(const Humain *h);

Humain * creerHumain();
