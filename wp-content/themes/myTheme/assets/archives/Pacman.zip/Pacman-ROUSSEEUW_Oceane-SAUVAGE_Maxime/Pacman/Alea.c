#include "Bibli.h"

int entierAlea_a_b(const int a, const int b){
    int n;

    if(a == b){
        return a;
    }

    if(a > b){
        n = rand()%(a-b)+b;
    } else {
        n = rand()%(b-a)+a;
    }

    return n;
}

void ajouterPieces(Plateau *p){
    int x, y, nb;
    nb = p->nbPieces;

    while(nb > 0){
        x = entierAlea_a_b(1,p->tailleX-1);
        y = entierAlea_a_b(1,p->tailleY-1);

        if(p->grille[x][y] == vide){
            p->grille[x][y] = piece;
            nb--;
        }
    }
}
