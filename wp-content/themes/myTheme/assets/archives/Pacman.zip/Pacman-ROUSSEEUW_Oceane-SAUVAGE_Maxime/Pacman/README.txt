Programme cr�� par ROUSSEEUW Oc�ane et SAUVAGE Maxime
/!\ L'antivirus peut emp�cher le programme de se lancer. /!\

Contact :

	- Oc�ane : oceane.rousseeuw@gmail.com

	- Maxime : maxime.sauvage1@gmail.com


gcc -Wall -Wextra Alea.c Humain.c Jeu.c ListeChainee.c main.c Menu.c Mur.c Plateau.c -o pacman


 ================================================.    
      .-.   .-.     .--.                         |    
     | OO| | OO|   / _.-' .-.   .-.  .-.   .''.  |    
     |   | |   |   \  '-. '-'   '-'  '-'   '..'  |    
     '^^^' '^^^'    '--'                         |    
 ===============.  .-.  .================.  .-.  |    
                | |   | |                |  '-'  |    
                | |   | |                |       |    
                | ':-:' |                |  .-.  |    
                |  '-'  |                |  '-'  |    
 ==============='       '================'       |