#include "Bibli.h"

Plateau * creerPlateau(int a, int b, int c, int d){
    Plateau *p = malloc(sizeof(Plateau));
    int i, j;

    p->tailleX = a+2; // On a fait le choix de compter les bords dans la taille
    p->tailleY = b+2;
    p->nbPieces = c;
    p->nbMurs = d;

    p->grille = malloc(p->tailleX*sizeof(Case *));
    for(i = 0; i < (p->tailleX); i++){
        p->grille[i] = malloc(p->tailleY*sizeof(Case));
    }

    for(i = 0; i < (p->tailleX); i++){
        p->grille[i][0] = mur;
        p->grille[i][p->tailleY-1] = mur;
    }

    for(i = 0; i < (p->tailleY); i++){
        p->grille[0][i] = mur;
        p->grille[p->tailleX-1][i] = mur;
    }

    for(i = 1; i < (p->tailleX-1); i++){
        for(j = 1; j < (p->tailleY-1); j++){
            p->grille[i][j] = vide;
        }
    }

    ajouterPieces(p);

    ajouterMurs(p);

    return p;
}

void afficherPlateau(const Plateau *p){
    int i,j;

    printf("\n");

    for(i = 0; i < p->tailleX; i++){
        printf(" ");

        for(j = 0; j < p->tailleY; j++){

            if(p->grille[i][j] == vide)
                printf(" ");

            if(p->grille[i][j] == mur)
                printf(ANSI_COLOR_BLUE "#" ANSI_COLOR_RESET);

            if(p->grille[i][j] == piece)
                printf(ANSI_COLOR_YELLOW "*" ANSI_COLOR_RESET);

            if(p->grille[i][j] == humain)
                printf(ANSI_COLOR_GREEN "H" ANSI_COLOR_RESET);

            if(p->grille[i][j] == fantome)
                printf(ANSI_COLOR_RED "F" ANSI_COLOR_RESET);

        }
        printf("\n");
    }
}

