typedef struct Coup{
    int posX;
    int posY;
    struct Coup *next;
}Coup;

typedef struct Fantome{
    int posX;
    int posY;
}Fantome;

typedef struct Jeu{
    Plateau *p;
    Humain *h;
    Fantome *f;
    int nbF;
}Jeu;

/* Signature des fonctions */

void afficherJeu(const Jeu *j);

Jeu * creerJeu(int tX, int tY, int nbP, int nbM, int nbF);

void initialiserJeu(Jeu *j);

int jouerCoup(Jeu *j, Coup *c);

void jouer(Jeu *j);
