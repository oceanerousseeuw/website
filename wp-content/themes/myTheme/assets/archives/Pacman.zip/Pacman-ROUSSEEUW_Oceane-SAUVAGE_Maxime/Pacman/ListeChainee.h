/* Signature des fonctions */

int compareCoups(const Coup *c1, const Coup *c2);

int coupExiste(const Coup *liste, const Coup *choix);

void afficherCoupsPossibles(const Coup *c);

void ajoutFin(Coup **liste, int x, int y);

Coup * choixCoup(Jeu *j);
