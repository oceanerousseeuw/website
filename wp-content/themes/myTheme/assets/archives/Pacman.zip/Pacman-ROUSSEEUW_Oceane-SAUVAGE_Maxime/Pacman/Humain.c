#include "Bibli.h"

void afficherHumain(const Humain *h){
    if(h->record != 0){ // Le record est intialis� � 0 dans la cr�ation d'un Humain
        printf("Nom : %s (%d,%d) - Score : %d - Record : %d\n", h->nom, h->posX, h->posY, h->score, h->record);
    } else {
        printf("Nom : %s (%d,%d) - Score : %d - Aucun record\n", h->nom, h->posX, h->posY, h->score);
    }
}

void recupererRecord(Humain *h){
    char rec[] = ".record";
    int taille;

    taille = strlen(h->nom) + strlen(rec); // On cherche la taille du nom ajout� � celle de rec (".record")

    char nomF[taille]; // On cr�er une nouvelle chaine avec la taille calcul�e
    strcpy(nomF,h->nom); // On copie le nom du joueur auquel on ajoute la chaine .rec
    strcat(nomF,rec);

    FILE *f = NULL;
    f = fopen(nomF, "r");

    if(!f){
        printf("Aucun record connu pour ce nom.\n");
    } else {

        while(!feof(f)){
            fscanf(f, "%d", &h->record);
        }

        printf("\nRecord recupere pour %s : %d\n", h->nom, h->record);
        pause();

        fclose(f);
    }
}

void sauverRecord(const Humain *h){
    char rec[] = ".record";
    int taille;

    taille = strlen(h->nom) + strlen(rec);

    char nomF[taille];
    strcpy(nomF,h->nom);
    strcat(nomF,rec);

    FILE *f = NULL;
    f = fopen(nomF, "w+");

    if(!f){
        printf("Erreur dans la sauvegarde du record.\n");
    } else {
        fprintf(f,"%d ",h->record);
        fclose(f);
    }
}

Humain * creerHumain(){
    Humain *h = malloc(sizeof(Humain));

    h->score = 0;
    h->record = 0;
    h->posX = 0;
    h->posY = 0;

    system(CLEAN_SCREEN);
    printf("  --  RECUPERATION DU RECORD  --  \n\n");
    printf("Saisir votre nom : ");
    scanf("%s",h->nom);

    recupererRecord(h);

    return h;
}
