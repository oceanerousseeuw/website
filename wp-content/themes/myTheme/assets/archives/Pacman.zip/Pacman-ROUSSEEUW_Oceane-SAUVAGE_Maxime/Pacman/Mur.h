/* Signature des fonctions */

int voisinsSansMurs(const Plateau *p, int x, int y);

int estUnCoin(const Plateau *p, int x, int y);

void rechercherPtDepart(const Plateau *p, int *x, int *y, int *dirX, int *dirY);

int tailleMax(const Plateau *p, int x, int y, int dirX, int dirY);

void construireUnMur(const Plateau *p, int x, int y, int dirX, int dirY, int longueurMax);

void ajouterMurs(Plateau *p);
